"""Generate one local RSA key pair for RedDust JWT signing."""
# RedDust: one-time local RS256 JWT key generator.
# Keep this helper and its generated keys out of Git

from pathlib import Path
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization

folder = Path("secrets")
folder.mkdir(exist_ok=True)

private_path = folder / "jwt-private.pem"
public_path = folder / "jwt-public.pem"

# Never overwrite existing signing keys.
if private_path.exists() or public_path.exists():
    raise SystemExit(
        "Refusing to overwrite existing signing key material"
    )

# Generate a 3072-bit RSA private key.
key = rsa.generate_private_key(
    public_exponent=65537,
    key_size=3072,
)

# Write the PRIVATE signing key.
private_path.write_bytes(
    key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
)

# Write the matching PUBLIC verification key.
public_path.write_bytes(
    key.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
)

print("Generated local JWT key files (contents not displayed)")