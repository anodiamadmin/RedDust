---
name: Outback Heritage
colors:
  surface: '#fff8f3'
  surface-dim: '#e7d8c4'
  surface-bright: '#fff8f3'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff2e1'
  surface-container: '#fbecd7'
  surface-container-high: '#f5e6d2'
  surface-container-highest: '#f0e0cc'
  on-surface: '#221a0e'
  on-surface-variant: '#59413b'
  inverse-surface: '#382f22'
  inverse-on-surface: '#feefda'
  outline: '#8d716a'
  outline-variant: '#e1bfb7'
  surface-tint: '#ae310f'
  primary: '#9b2401'
  on-primary: '#ffffff'
  primary-container: '#bd3c1a'
  on-primary-container: '#ffe4de'
  inverse-primary: '#ffb4a2'
  secondary: '#974800'
  on-secondary: '#ffffff'
  secondary-container: '#ff9243'
  on-secondary-container: '#6b3100'
  tertiary: '#744531'
  on-tertiary: '#ffffff'
  tertiary-container: '#905d47'
  on-tertiary-container: '#ffe5db'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbd2'
  primary-fixed-dim: '#ffb4a2'
  on-primary-fixed: '#3c0800'
  on-primary-fixed-variant: '#891e00'
  secondary-fixed: '#ffdbc7'
  secondary-fixed-dim: '#ffb688'
  on-secondary-fixed: '#311300'
  on-secondary-fixed-variant: '#733600'
  tertiary-fixed: '#ffdbcd'
  tertiary-fixed-dim: '#f9b89d'
  on-tertiary-fixed: '#331103'
  on-tertiary-fixed-variant: '#683b27'
  background: '#fff8f3'
  on-background: '#221a0e'
  surface-variant: '#f0e0cc'
typography:
  display-lg:
    fontFamily: Literata
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Literata
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Literata
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  body-md:
    fontFamily: Literata
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 28px
  label-sm:
    fontFamily: Work Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  gutter: 24px
  margin-mobile: 20px
  margin-desktop: 64px
  container-max: 1280px
---

## Brand & Style

This design system draws inspiration from the rugged, majestic landscapes of the Australian Outback at dusk. The brand personality is adventurous yet grounded, evocative of ancient lands and modern exploration. It targets travelers, historians, and outdoor enthusiasts who value authenticity and high-quality storytelling.

The visual style is **Tactile Minimalism**. It avoids the sterility of pure digital interfaces by incorporating subtle organic textures and a palette rooted in geology. The UI should evoke an emotional response of warmth, stability, and wanderlust, using the "Red Road" logo as a central metaphor for the user's journey.

## Colors

The color palette is derived directly from the desert's horizon. The primary color is a deep, oxidized red-earth tone, used for key actions and branding. The secondary orange mimics the setting sun, providing a high-energy contrast for highlights and active states. 

Departing from stark cream, the background uses a more saturated, sun-baked clay tone (#F2E6D8) that feels like aged parchment or dusty earth. Neutral tones are warm and desaturated browns rather than greys, ensuring the interface feels cohesive and natural.

## Typography

This design system relies on the literary and authoritative character of **Literata** for both display and body text. This creates a "journalistic" or "explorer’s log" feel. For utilitarian elements like labels, timestamps, and captions, **Work Sans** is used to provide a clean, modern counterpoint that ensures legibility at small sizes.

Headlines should utilize "Optical Sizing" where available, tightening letter spacing at larger sizes to emphasize the font’s elegant serifs. Body text is set with generous line height to honor the slow, intentional pace of the brand narrative.

## Layout & Spacing

The layout philosophy follows a **Fixed Grid** model on desktop to maintain an editorial feel, centered within the viewport. On mobile, it transitions to a fluid, single-column layout with 20px safe margins.

The spacing rhythm is based on an 8px baseline grid, though larger "breathable" gaps are encouraged between sections to mimic the vastness of the outback landscape. Vertical rhythm is critical; maintain 48px to 64px of space between major content blocks to avoid visual clutter and maintain a premium, relaxed atmosphere.

## Elevation & Depth

Depth is achieved through **Tonal Layering** rather than traditional drop shadows. Surfaces appear to "rest" on one another. 

- **Surface Levels:** The base background is the most "recessed." Cards and containers use a slightly lighter, more luminous version of the background color or a subtle paper-like texture.
- **Shadows:** When necessary for high-priority modals, use "Ambient Shadows" — extremely soft, wide-dispersion shadows tinted with the primary red-earth color at 5% opacity. This makes elements feel like they are casting a shadow on red sand rather than a grey void.
- **Dividers:** Use low-contrast hairline borders in a darker tint of the background color to separate content without breaking the flow.

## Shapes

The shape language is organic and approachable. Following the "roundedness 2" standard, UI elements feel soft and weathered, like stones smoothed by wind and water. 

Corners should never be sharp. Buttons, input fields, and cards utilize a 0.5rem (8px) radius as the base, with larger containers scaling up to 1.5rem (24px) to create a "nested" visual harmony. Interactive icons and small avatars should be fully circular to echo the sun motif in the logo.

## Components

- **Buttons:** Primary buttons use the deep red background with white (cream) text. They feature a subtle inner-glow on hover to simulate the sun catching an edge.
- **Cards:** Cards should have a 1px border of #D9C5B2 and a very subtle grain texture background. Content within should be heavily padded (minimum 24px).
- **Input Fields:** Fields are "underlined" or "bottom-bordered" only in high-editorial views, but use fully enclosed rounded containers in functional forms. The focus state uses the secondary orange as a soft outer glow.
- **Chips/Tags:** Use the tertiary brown for background with light cream text, reinforcing the earthy palette.
- **Navigation:** Top-level navigation should be minimal, using Work Sans in all-caps for a clear, directional feel, mimicking trailhead signage.