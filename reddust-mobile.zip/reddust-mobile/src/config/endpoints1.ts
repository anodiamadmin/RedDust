function requiredHttps(name: string, value?: string) {
  if (!value || !/^https:\/\/[^\s/]+/i.test(value)) {
    throw new Error(`${name} must be a valid HTTPS base URL`);
  }
  return value.replace(/\/+$/, "");
}
export const AUTH_BASE = requiredHttps(
  "EXPO_PUBLIC_AUTH_API_URL",
  process.env.EXPO_PUBLIC_AUTH_API_URL,
);
export const GATEWAY_BASE = requiredHttps(
  "EXPO_PUBLIC_GATEWAY_URL",
  process.env.EXPO_PUBLIC_GATEWAY_URL,
);
export const WEB_CLIENT_ID = process.env.EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID;
if (!WEB_CLIENT_ID) throw new Error("Missing Google Web client ID");
